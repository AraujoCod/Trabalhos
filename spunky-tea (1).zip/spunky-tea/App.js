import * as React from 'react';
import { Text, View, Image, StyleSheet, Button } from 'react-native';
import Constants from 'expo-constants';

// You can import from local files
import AssetExample from './components/AssetExample';

// or any pure javascript modules available in npm
import { Card } from 'react-native-paper';

export default function App() {
  return (
    <View style={styles.container}>
      <Text style={styles.paragraph}>
        <Image style={{width: 240, height:240 }} source={require('./Duolingo_logo_PNG1.png')}/>
      </Text>
      <Text style={styles.texto}>
       Learn a language for free.
      </Text>
      <Text style={styles.texto}>
       Forever.
      </Text>
      <Button style={styles.botao}
          onPress={() => {
            setIsHungry(false);
           }}
        />
        <Text>
        ㅤ
        
        </Text>
        <Text>
        ㅤ
        
        </Text>
      <Button style={styles.botao}
          onPress={() => {
            setIsHungry(false);
           }}
        />


    </View>

    
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    paddingTop: Constants.statusBarHeight,
    backgroundColor: '#ecf0f1',
    padding: 8,
  },
  paragraph: {
    margin: 24,
    fontSize: 40,
    fontWeight: 'bold',
    textAlign: 'center',
    color: 'green',
    fontFamily: 'Roboto',
  },
  texto: {
    textAlign: 'center',
    color: 'gray'
  },

  botao: {
    textAlign: 'center',
    margin: 24,
    
  },
  

});

